# A Kernel Seedling

This module writes the number of processes running to /proc/count.

## Building

You can build the kernel module by changing into the directory and running
the "make" command. You can then run "sudo insmod proc_count.ko" to insert the
module.

## Running

After running "sudo insmod proc_count.ko", you can see the current processes
by running "cat /proc/count".

## Cleaning Up

You can remove the module by running "sudo rmmod proc_count".

## Testing

Tested on version 5.14.8.
