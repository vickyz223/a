#include <linux/module.h>
#include <linux/printk.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/sched.h>

static int proc_show(struct seq_file *m, void *v) {
	struct task_struct* tasks;
	int num_processes = 0;
	for_each_process(tasks) {
		++num_processes;
	}
	seq_printf(m, "%d\n", num_processes);
	return 0;
}

static int count_proc_open(struct inode *inode, struct  file *file) {
  	return single_open(file, proc_show, NULL);
}

static const struct proc_ops count_proc_ops = {
  	.proc_open = count_proc_open,
	.proc_release = single_release,
	.proc_read = seq_read,
	.proc_lseek = seq_lseek,
};

static int __init count_proc_init(void) {
	proc_create("count", 0, NULL, &count_proc_ops);
	return 0;
}

static void __exit count_proc_exit(void) {
  	remove_proc_entry("count", NULL);
}

module_init(count_proc_init);
module_exit(count_proc_exit);

MODULE_AUTHOR("Your name");
MODULE_DESCRIPTION("One sentence description");
MODULE_LICENSE("GPL");